# 🍽️ El Rincón del Poblado — Sitio Web Restaurante

Sitio web completo y responsivo para restaurante colombiano, desarrollado como proyecto de portafolio.

## 🚀 Demo

Abre `index.html` en tu navegador o despliega en [Netlify](https://netlify.com) / [Vercel](https://vercel.com) en menos de 2 minutos.

## ✨ Características

- **Diseño moderno y responsivo** — se adapta a móvil, tablet y escritorio
- **Navegación fija** con efecto blur al hacer scroll
- **Sección Hero** con estadísticas del restaurante
- **Menú de platos** con categorías y precios
- **Formulario de reservas** funcional
- **Mapa de ubicación** y datos de contacto
- **Animaciones CSS** suaves al cargar la página
- **Sin dependencias externas** — solo HTML, CSS y JavaScript vanilla

## 🛠️ Tecnologías

- HTML5 semántico
- CSS3 (Grid, Flexbox, Variables CSS, Animaciones)
- JavaScript vanilla
- Google Fonts (Playfair Display + DM Sans)

## 📁 Estructura

```
restaurante-el-poblado/
└── index.html       # Sitio completo en un solo archivo
```

## 🚀 Despliegue rápido en Netlify

1. Ve a [netlify.com](https://netlify.com)
2. Arrastra la carpeta del proyecto al dashboard
3. ¡Listo! Tienes una URL pública en segundos

## 📸 Secciones

| Sección | Descripción |
|---------|-------------|
| Hero | Presentación principal con plato destacado |
| Nosotros | Historia y valores del restaurante |
| Menú | 6 platos con nombre, descripción y precio |
| Reservas | Formulario completo + datos de contacto |

## 👨‍💻 Desarrollado por

**Camilo Rodríguez** — Estudiante de Ingeniería de Sistemas, EAFIT  
Disponible para proyectos freelance en [Workana](https://workana.com)

---
*Este es un proyecto ficticio desarrollado con fines de portafolio.*
